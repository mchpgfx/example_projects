#include "gfx/legato/generated/screen/le_gen_screen_Screen0.h"

// screen member widget declarations
static leWidget* root0;

leWidget* Screen0_BackgroundPanel;
leButtonWidget* Screen0_ButtonWidget_0;
leWidget* Screen0_PanelExample;
leWidget* Screen0_PanelExample1;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_Screen0(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_Screen0(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 480, 272);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    Screen0_BackgroundPanel = leWidget_New();
    Screen0_BackgroundPanel->fn->setPosition(Screen0_BackgroundPanel, 0, 0);
    Screen0_BackgroundPanel->fn->setSize(Screen0_BackgroundPanel, 480, 272);
    Screen0_BackgroundPanel->fn->setScheme(Screen0_BackgroundPanel, &WhiteScheme);
    root0->fn->addChild(root0, (leWidget*)Screen0_BackgroundPanel);

    Screen0_ButtonWidget_0 = leButtonWidget_New();
    Screen0_ButtonWidget_0->fn->setPosition(Screen0_ButtonWidget_0, 39, 110);
    Screen0_ButtonWidget_0->fn->setSize(Screen0_ButtonWidget_0, 126, 35);
    Screen0_ButtonWidget_0->fn->setScheme(Screen0_ButtonWidget_0, &BlueScheme);
    Screen0_ButtonWidget_0->fn->setString(Screen0_ButtonWidget_0, (leString*)&string_panel);
    Screen0_ButtonWidget_0->fn->setPressedEventCallback(Screen0_ButtonWidget_0, event_Screen0_ButtonWidget_0_OnPressed);
    Screen0_ButtonWidget_0->fn->setReleasedEventCallback(Screen0_ButtonWidget_0, event_Screen0_ButtonWidget_0_OnReleased);
    root0->fn->addChild(root0, (leWidget*)Screen0_ButtonWidget_0);

    Screen0_PanelExample = leWidget_New();
    Screen0_PanelExample->fn->setPosition(Screen0_PanelExample, 256, 23);
    Screen0_PanelExample->fn->setSize(Screen0_PanelExample, 140, 103);
    Screen0_PanelExample->fn->setScheme(Screen0_PanelExample, &YellowScheme);
    Screen0_PanelExample->fn->setBorderType(Screen0_PanelExample, LE_WIDGET_BORDER_BEVEL);
    root0->fn->addChild(root0, (leWidget*)Screen0_PanelExample);

    Screen0_PanelExample1 = leWidget_New();
    Screen0_PanelExample1->fn->setPosition(Screen0_PanelExample1, 257, 145);
    Screen0_PanelExample1->fn->setSize(Screen0_PanelExample1, 140, 103);
    Screen0_PanelExample1->fn->setScheme(Screen0_PanelExample1, &OrangeScheme);
    Screen0_PanelExample1->fn->setBorderType(Screen0_PanelExample1, LE_WIDGET_BORDER_BEVEL);
    root0->fn->addChild(root0, (leWidget*)Screen0_PanelExample1);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_Screen0(void)
{
    root0->fn->setSize(root0, root0->rect.width, root0->rect.height);
}

void screenHide_Screen0(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    Screen0_BackgroundPanel = NULL;
    Screen0_ButtonWidget_0 = NULL;
    Screen0_PanelExample = NULL;
    Screen0_PanelExample1 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_Screen0(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_Screen0(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

